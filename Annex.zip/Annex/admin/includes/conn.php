<?php
$conn = mysqli_connect('localhost','root','','annex');
if(!$conn)
{
    echo 'Error connection failed';
}
?>