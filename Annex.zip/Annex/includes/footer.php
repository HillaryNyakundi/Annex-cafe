    <footer class="footer">
        <p>
            <span class="nowrap">copyright &copy; <time id="year"></time></span>
            <span class="nowrap">Annex Cafe</span>
        </p>
    </footer>