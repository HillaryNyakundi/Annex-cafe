    <header class="header">
        <h1 class="header__h1"> Welcome to Annex Cafe</h1>
        <nav class="header__nav">
            <ul class="header__ul">
                <li>
                    <a href="index.php">Menu</a>
                </li>
                <li>
                    <a href="hours.php">Hours</a>
                </li>
                <li>
                    <a href="contact.php">Contact</a>
                </li>
                <li>
                <a href="about.php">About</a>
                </li>
            </ul>
        </nav>
    </header>